// const box = document.getElementById('ChatWindow')
// const btn = document.getElementById('BtnChat')

// box.addEventListener('touchstart', e => e.preventDefault())

// btn.addEventListener('click', () => {
//   box.classList.toggle('ChatWindow-hide')
//   btn.classList.toggle('BtnChat-close')
// })

// $(document).ready(function() {
//   $('#show-hidden-menu').click(function() {
//     $('.hidden-menu').slideToggle("slow");
//     // Alternative animation for example
//     // slideToggle("fast");
//   });
// });


function openForm() {
  document.getElementById("myForm").style.display = "block";
  document.getElementById("BtnChat").style.display = "none";

}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
  document.getElementById("BtnChat").style.display = "flex";
}