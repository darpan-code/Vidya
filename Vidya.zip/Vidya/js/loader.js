
    setTimeout(function(){
        $('.loader_bg').fadeToggle();
    }, 1000);