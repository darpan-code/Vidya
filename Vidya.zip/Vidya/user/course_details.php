<!-- database link -->

<?php
  if(!isset($_SESSION)){
    session_start();
  }
    date_default_timezone_set('Asia/Kolkata');
    include('../database/connection.php');
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="user_css/course_details.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>


    <!-- navbar -->
   
    <div class="user_nav">
    <a href="../index.php"><div class="user_navlink">  <i class="fas fa-home"></i> Home </div></a>
    <a href="all_course.php"><div class="user_navlink">  All Courses </div></a>
    <a href="english_course.php"><div class="user_navlink"> English Courses </div></a>
    <a href="hindi_course.php"><div class="user_navlink"> Hindi Courses </div></a>
    <a href="bengali_course.php"><div class="user_navlink"> Bengali Courses </div></a>
    <a href="user_dash.php"><div class="user_navlink"> <i class="fas fa-user-circle"></i> </div></a>
    </div>


    <?php 
        if(isset($_GET['course_id'])){
            $course_id = $_GET['course_id'];
            $_SESSION['course_id'] = $_GET['course_id'];
            $sql = "SELECT * FROM course WHERE course_id = '$course_id'";
            $result = $con->query($sql);
            $row = $result->fetch_assoc();
        }
    ?>

    <div class="course_details_container">
        <div class="course_details_main">
            <div class="course_image">
                <img src="<?php echo $row['course_image']?>" alt="course image">
            </div>
            <div class="course_details">
                <p class="_name"><?php echo $row['course_name']?></p>
                <p class="_desc"><?php echo $row['course_description']?></p>
                <div class="pd">
                    <p class="_lang"><span class="_bold">Language:</span> <?php echo $row['course_language']?></p>
                    <p class="_durration"><span class="_bold">Duration:</span> <?php echo $row['course_duration']?></p>
                </div>
                
                <div class="pd">
                    <p class="_author"><span class="_bold">Author:</span> <?php echo $row['course_author']?></p>
                    <p class="_price"><span class="_bold">Price:</span> <span class="_orgPrice">&#8377;<?php echo $row['course_original_price']?></span> &#8377;<?php echo $row['course_selling_price']?></p>
                </div>

                <form action="checkout.php" method="post">
                <input type="hidden" name="id" value="<?php echo $row['course_selling_price']?>">
                <div class="course_view_enroll">
                    <button type="submit" class="btn_enroll">
                        Enroll Now
                    </button>
                </div>
                </form>
            </div>
        </div>


                    <?php
                            $sql = "SELECT * FROM lesson WHERE course_id = '$course_id'";
                            $result = $con->query($sql);
                             echo '  <table class="table">
                                    <thead class="table-info">
                                        <tr>
                                        <th scope="col">Lesson No.</th>
                                        <th scope="col">Lesson Name</th>
                                        </tr>
                                    </thead>
                                    <tbody>';
                            if($result->num_rows > 0){
                                while($row = $result->fetch_assoc()){
                                    echo' 
                                        <tr>
                                        <th scope="row">'.$row['lesson_id'].'</th>
                                        <td>'.$row['lesson_name'].'</td>
                                        </tr>';
                                }          
            
                            }

                            echo '  </tbody>
                            </table>'
                    ?>

                   
    

    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>