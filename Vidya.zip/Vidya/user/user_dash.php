<?php require_once "../database/controllerUserData.php"; ?>
<?php 



    if(isset($_SESSION['email'])){
        $useremail = $_SESSION['email'];
      
    $sql = "SELECT * FROM user WHERE email = '$useremail'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $rows = mysqli_fetch_assoc($run_Sql);
        $status = $rows['status'];
        $code = $rows['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: ../reset-code.php');
            }
        }else{
            header('Location: ../user-otp.php');
        }
    }
}else{
    header('Location: ../login-user.php');
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="user_css/user_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">

</head>
<body>

    <!-- navbar -->
    
    <div class="user_nav">
    <a href="user_dash.php"><div class="user_navlink active">  Dashboard </div></a>
    <a href="user_course.php"><div class="user_navlink"> My Course </div></a>
    <a href="all_course.php"><div class="user_navlink"> All Course </div></a>
    <a href="user_paymentStatus.php"><div class="user_navlink"> Payment Status </div></a>
    <a href="user_feedback.php"><div class="user_navlink"> Feedback </div></a>
    <a href="user_profile.php"><div class="user_navlink"> <i class="fas fa-user-circle"></i> </div></a>
    <a href="../logout-user.php"><div class="user_navlink"> <i class="fas fa-sign-out-alt"></i></div></a>
    </div>


    <div class="user_container">
        <div class="user_image">
            <img src="<?php echo $rows['image']?>" alt="User Profile">
        </div>
        <div class="user_profile">
            <div class="user_details">
                <div class="user_name">
                    <div class="_name"><?php echo $rows['name'] ?></div>
                    <div class="_occu"><?php echo $rows['occupation'] ?></div>
                    <div class="_email"><?php echo $rows['email'] ?></div>
                </div>
                <div class="user_id">
                    <div>ID</div>
                    <div><?php echo $rows['id'] ?></div>
                </div>
            </div>
        </div>
    </div>





    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>