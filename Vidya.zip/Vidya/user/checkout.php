<!-- database link -->
<?php require_once "../database/controllerUserData.php"; ?>
<?php 
  if(isset($_SESSION['email'])){
    $useremail = $_SESSION['email'];
    }else{
    header('location:../login-user.php');
    }

?>


<?php
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="GENERATOR" content="Evrsoft First Page">
    <title>Checkout</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link href="../css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- <link href="user_css/course_details.css" rel="stylesheet"> -->
    <!-- <link href="../css/media.css" rel="stylesheet"> -->
</head>
<body>
<div class="container mt-5">
        <div class="row">
            <div class="col-sm-6 offset-sm-3 jumbotron">
                <h3 class="mb-5 text-center">Welcome to Vidya Payment Page</h3>
      
        <form method="post" action="../PaytmKit/pgRedirect.php">
            <div class="form-group row">
                <label for="ORDER_ID" class="col-sm-4 col-form-lable">Order ID</label>
                <div class="col-sm-8">
                <input type="text" id="ORDER_ID" class="form-control" tabindex="1" maxlength="20" size="20" name="ORDER_ID" autocomplete="off" value="<?php echo  "ORDS" . rand(10000,99999999)?>" readonly>
                </div>
            </div>

            <div class="form-group row">
                <label for="CUST_ID" class="col-sm-4 col-form-lable">Student Email</label>
                <div class="col-sm-8">
                <input type="text" id="CUST_ID" class="form-control" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="<?php if(isset($useremail)){echo $useremail;}?>" readonly>
                </div>
            </div>

            <div class="form-group row">
                <label for="TXN_AMOUNT" class="col-sm-4 col-form-lable">Amount</label>
                <div class="col-sm-8">
                <input type="text" id="TXN_AMOUNT" class="form-control" tabindex="3" maxlength="12" size="12" name="TXN_AMOUNT" autocomplete="off" value="<?php if(isset($_POST['id'])){echo $_POST['id'];}?>" readonly>
                </div>
            </div>

            <div class="form-group row">
                <!-- <label for="TXN_AMOUNT" class="col-sm-4 col-form-lable">Amount</label> -->
                <div class="col-sm-8">
                <input type="hidden" id="INDUSTRY_TYPE_ID" class="form-control" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail" readonly>
                </div>
            </div>

            <div class="form-group row">
                <!-- <label for="TXN_AMOUNT" class="col-sm-4 col-form-lable">Amount</label> -->
                <div class="col-sm-8">
                <input type="hidden" id="CHANNEL_ID" class="form-control" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB" readonly>
                </div>
            </div>

            <div class="text-center">
                <!-- <label for="TXN_AMOUNT" class="col-sm-4 col-form-lable">Amount</label> -->
                <input type="submit" class="btn btn-primary" onclick="" value="Pay Now">
                <a href="./all_course.php" class="btn btn-secondary">Cancle</a>
            </div>
        </form>
        <div style="margin-top:1rem;" class="p-1 mb-2 bg-dark text-white">Note: Complete Patment by Clicking Pay Now Button</div>
        <div class="p-3 mb-2 bg-danger text-white">Please copy or take a Screenshot of this Order ID for future reference...</div>
        </div>
    </div>
</div>
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>