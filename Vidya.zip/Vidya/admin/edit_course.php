<?php 
    if(!isset($_SESSION)){
            session_start();
        }
    
        if(isset($_SESSION['is_admin_login'])){
            $adminEmail = $_SESSION['admin'];
            }else{
            header('location:../index.php');
            }

    include('admindata/course_db.php');


    //Update course details 
    
    if(isset($_REQUEST['requpdate'])){

        // checking for empty fields 

    if(($_REQUEST['course_id'] == "") ||
     ($_REQUEST['course_name'] == "") ||
     ($_REQUEST['course_desc'] == "") || 
     ($_REQUEST['author_name'] == "") || 
     ($_REQUEST['course_language'] == "") || 
     ($_REQUEST['course_duration'] == "") || 
     ($_REQUEST['course_original_price'] == "") || 
     ($_REQUEST['course_quiz'] == "") || 
     ($_REQUEST['course_selling_price'] == "")
     ){
         //if filds missing
         $msg = '<div class="fill_error">Fill All Fields</div>';
         echo '<meta http-equiv="refresh" content="0;URL=?fillallfields" />';
     }
     else {
          $cid = $_REQUEST['course_id'];
          $cname = $_REQUEST['course_name'];
          $cdesc = $_REQUEST['course_desc'];
          $cauthor = $_REQUEST['author_name'];
          $clanguage = $_REQUEST['course_language'];
          $cduration = $_REQUEST['course_duration'];
          $coriginalprice = $_REQUEST['course_original_price'];
          $csellingprice = $_REQUEST['course_selling_price'];
          $course_quiz = $_REQUEST['course_quiz'];

          $img_folder = $_REQUEST['image'];
        
          if($_FILES['course_img']['error'] == 0){
          $course_image = $_FILES['course_img']['name'];
          $course_image_temp = $_FILES['course_img']['tmp_name'];
          $img_folder = '../img/course/'.$course_image;
          move_uploaded_file($course_image_temp, $img_folder);
          }


          $sql = "UPDATE course SET course_name = '$cname', course_description = '$cdesc', course_author= '$cauthor', course_language= '$clanguage', course_image= '$img_folder', course_duration='$cduration', course_selling_price='$csellingprice', course_original_price='$coriginalprice', quiz_link='$course_quiz'
          WHERE course_id = '$cid'";

          if($conn->query($sql) == TRUE){

            // //submit success
            //  $msg = '<div class="add_success">Course Update Succesfully</div>';
            //  echo '<meta http-equiv="refresh" content="0;URL=?updated" />';
            header("Location: admin_course.php");
         }
         else{
            //  $msg = '<div class="fill_error">Unable to Update Course</div>';
            //  echo '<meta http-equiv="refresh" content="0;URL=?fail_to_update" />';
         }
     }
 }
?>





<!DOCTYPE html>
<html>
<head>
	<title>Edit Course</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="admin_css/edit_course.css">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>
<div class="edit_body">
    <div class="edit_course_main">
        <div class="edit_course_head">Edit Course</div>

        <?php
            if(isset($_REQUEST['view'])){
                $sql = "SELECT * FROM course WHERE course_id = {$_REQUEST['c_id']}";

            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
        }
        ?>

        <div class="edit_course_upper">
            <form class="edit_course_login" action="" method="POST" enctype="multipart/form-data">
                
                <input class="edit_course_textbox form-control" type="text" id="course_id" name="course_id" placeholder="Type your course id here..." value="<?php if(isset($row['course_id'])) {echo $row['course_id'] ;}?>" readonly>

                <input class="edit_course_textbox form-control" type="text" id="course_name" name="course_name" placeholder="Type your course name here..." value="<?php if(isset($row['course_name'])) {echo $row['course_name'] ;}?>" required>
                
                <textarea class="edit_course_textbox form-control" id="course_desc" name="course_desc" placeholder="Type your description here..." value="<?php if(isset($row['course_description'])) {echo $row['course_description'] ;}?>" required><?php if(isset($row['course_description'])) {echo $row['course_description'] ;}?></textarea>
                
                <input class="edit_course_textbox form-control" type="text" id="author_name" name="author_name" placeholder="Type author name here..." value="<?php if(isset($row['course_author'])) {echo $row['course_author'] ;}?>" required>

                <select class="edit_course_textbox form-control" name="course_language" id="course_language" placeholder="Select language here..." required>
                    <option value="<?php if(isset($row['course_language'])) {echo $row['course_language'] ;}?>"><?php if(isset($row['course_language'])) {echo $row['course_language'] ;}?></option>
                    <option value="English">English</option>
                    <option value="Hindi">Hindi</option>
                    <option value="Bengali">Bengali</option>
                </select>

                <input class="edit_course_textbox form-control" type="text" id="course_duration" name="course_duration" placeholder="Type course duration here..." value="<?php if(isset($row['course_duration'])) {echo $row['course_duration'] ;}?>" required>
                
                <input class="edit_course_textbox form-control" type="text" id="course_original_price" name="course_original_price" placeholder="Type your original price here..." value="<?php if(isset($row['course_original_price'])) {echo $row['course_original_price'] ;}?>" required>
                
                <input class="edit_course_textbox form-control" type="text" id="course_selling_price" name="course_selling_price" placeholder="Type your selling price here..." value="<?php if(isset($row['course_selling_price'])) {echo $row['course_selling_price'] ;}?>" required>
                
                <input class="edit_course_textbox form-control" type="text" id="course_quiz" name="course_quiz" placeholder="Type your Quiz link here..." value="<?php if(isset($row['quiz_link'])) {echo $row['quiz_link'] ;}?>" required>

                <img style="height:8rem; border-radius:1rem;" src="<?php if(isset($row['course_image'])) {echo $row['course_image'] ;}?>" >

                <input type="hidden" name="image" value="<?php if(isset($row['course_image'])) {echo $row['course_image'] ;}?>">

                <input type="file" class="edit_course_textbox form-control" id="course_img" name="course_img" accept="image/png, image/jpeg">
                
                <input class="edit_course_submit" id="requpdate" type="submit" value="Update" name="requpdate">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>
</div>


</body>
</html>


