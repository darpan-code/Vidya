<?php 

    if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }

    include('admindata/course_db.php');

    // checking for entry 
    if(isset($_REQUEST['query_update'])){

       if(
       ($_REQUEST['bot_question'] == "") ||
       ($_REQUEST['bot_answer'] == "")
        ){
            $msg = '<div class="fill_error">Fill All Fields</div>';
            echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
        }
        else {
            $query_id = $_REQUEST['query_id'];
            $bot_question = $_REQUEST['bot_question'];
            $bot_answer = $_REQUEST['bot_answer'];

            $sql = "UPDATE chatbot_hints SET question = '$bot_question', reply = '$bot_answer' WHERE id = '$query_id'";



             if($conn->query($sql) == TRUE){
                // $msg = '<div class="add_success">Query Update Succesfully</div>';
                // echo '<meta http-equiv="refresh" content="0;URL=?Query_Update_Succesfully" />';
                header("Location: help_center.php");

            }
            else{
                // $msg = '<div class="fill_error">Unable to Edit Query</div>';
                // echo '<meta http-equiv="refresh" content="0;URL=?Unable_to_Update_Query" />';
            }
        }
    }
?>


<!DOCTYPE html>
<html>
<head>
	<title>Edit Query</title>
	<link rel="stylesheet" type="text/css" href="admin_css/edit_query.css">
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="admin_css/edit_query.css">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>
<div class="edit_body">

    <div class="edit_query_main">
        <div class="edit_query_head">Edit Query</div>

        <?php
            if(isset($_REQUEST['view'])){
                $sql = "SELECT * FROM chatbot_hints WHERE id = {$_REQUEST['q_id']}";

            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
        }
        ?>

        <div class="edit_query_upper">
            <form class="edit_query_login" action="" method="POST" enctype="multipart/form-data">

            <input class="edit_query_textbox form-control" type="text" id="query_id" name="query_id" placeholder="Type your query id here..." value="<?php if(isset($row['id'])) {echo $row['id'] ;}?>" required>

            <textarea class="edit_query_textbox form-control" id="bot_question" name="bot_question" placeholder="Type your question here..." value="<?php if(isset($row['question'])) {echo $row['question'] ;}?>" required><?php if(isset($row['question'])) {echo $row['question'] ;}?></textarea>

            <textarea class="edit_query_textbox form-control" id="bot_answer" name="bot_answer" placeholder="Type your answer here..." value="<?php if(isset($row['reply'])) {echo $row['reply'] ;}?>" required><?php if(isset($row['reply'])) {echo $row['reply'] ;}?></textarea>
          
            <input class="edit_query_submit" type="submit" value="Update" name="query_update">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>
    </div>


</body>
</html>


