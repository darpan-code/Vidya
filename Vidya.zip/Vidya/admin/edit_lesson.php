<?php 
    if(!isset($_SESSION)){
            session_start();
        }
    
        if(isset($_SESSION['is_admin_login'])){
            $adminEmail = $_SESSION['admin'];
            }else{
            header('location:../index.php');
            }

    include('admindata/course_db.php');


    //Update lesson details 
    
    if(isset($_REQUEST['update_lesson'])){

        // checking for empty fields 

    if(($_REQUEST['course_id'] == "") ||
     ($_REQUEST['course_name'] == "") ||
     ($_REQUEST['lesson_id'] == "") || 
     ($_REQUEST['lesson_name'] == "") || 
     ($_REQUEST['lesson_desc'] == "")
     ){
         //if filds missing
         $msg = '<div class="fill_error">Fill All Fields</div>';
         echo '<meta http-equiv="refresh" content="0;URL=?fillallfields" />';
     }
     else {
          $course_id = $_REQUEST['course_id'];
          $course_name = $_REQUEST['course_name'];
          $lesson_id = $_REQUEST['lesson_id'];
          $lesson_name = $_REQUEST['lesson_name'];
          $lesson_desc = $_REQUEST['lesson_desc'];


          $video_folder = $_REQUEST['video'];
        
          if($_FILES['lesson_video']['error'] == 0){
            $lesson_video = $_FILES['lesson_video']['name'];
            $lesson_video_temp = $_FILES['lesson_video']['tmp_name'];
            $video_folder = '../lesson_video/'.$lesson_video;
            move_uploaded_file($lesson_video_temp, $video_folder);
          }


          $sql = "UPDATE lesson SET lesson_name = '$lesson_name', lesson_desc= '$lesson_desc', lesson_link= '$video_folder' WHERE lesson_id = '$lesson_id'";

          if($conn->query($sql) == TRUE){

            //submit success
            //  $msg = '<div class="edit_success">Lesson Update Succesfully</div>';
            //  echo '<meta http-equiv="refresh" content="0;URL=?updated" />';
            header("Location: admin_lessons.php");
         }
         else{
            //  $msg = '<div class="fill_error">Unable to Update Lesson</div>';
            //  echo '<meta http-equiv="refresh" content="0;URL=?fail_to_update" />';
         }
     }
 }
?>





<!DOCTYPE html>
<html>
<head>
	<title>Edit Lesson</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="admin_css/edit_lesson.css">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>
<div class="edit_body">

        <?php
            if(isset($_REQUEST['view'])){
                $sql = "SELECT * FROM lesson WHERE lesson_id = {$_REQUEST['l_id']}";

            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
        }
        ?>

<div class="edit_lesson_main">
        <div class="edit_lesson_head"> Edit Lesson</div>
        <div class="edit_lesson_upper">
            <form class="edit_lesson_login" action="" method="POST" enctype="multipart/form-data">
                
                <input class="edit_lesson_textbox form-control" type="text" id="course_id" name="course_id" placeholder="Type your course id here..." value="<?php if(isset($_SESSION['course_id'])) {echo $_SESSION['course_id'];} ?>" readonly>

                <input class="edit_lesson_textbox form-control" type="text" id="course_name" name="course_name" placeholder="Type your course name here..." value="<?php if(isset($_SESSION['course_name'])) {echo $_SESSION['course_name'];} ?>" readonly>
                
                <input class="edit_lesson_textbox form-control" type="text" id="lesson_id" name="lesson_id" placeholder="Type your lesson id here..." value="<?php if(isset($row['lesson_id'])) {echo $row['lesson_id'] ;}?>" required>
                
                <input class="edit_lesson_textbox form-control" type="text" id="lesson_name" name="lesson_name" placeholder="Type your lesson name here..." value="<?php if(isset($row['lesson_name'])) {echo $row['lesson_name'] ;}?>" required>
                
                <textarea class="edit_lesson_textbox form-control" id="lesson_desc" name="lesson_desc" placeholder="Type your lesson description here..." value="<?php if(isset($row['lesson_desc'])) {echo $row['lesson_desc'] ;}?>" required><?php if(isset($row['lesson_desc'])) {echo $row['lesson_desc'] ;}?></textarea>
               
                <video style = "height:20rem;"  controls>
                      <source src="<?php if(isset($row['lesson_link'])) {echo $row['lesson_link'] ;}?>" type="video/mp4">
                </video>

                <input type="hidden" name="video" value="<?php if(isset($row['lesson_link'])) {echo $row['lesson_link'] ;}?>">

                <input type="file" class="edit_lesson_textbox form-control" id="lesson_video" name="lesson_video" accept="video/mp4,video/x-m4v,video/*">
                
                <input class="edit_lesson_submit" type="submit" value="Update" name="update_lesson">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>
    </div>
</body>
</html>


