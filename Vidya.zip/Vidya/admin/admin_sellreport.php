<?php
if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }

        include('admindata/course_db.php');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sell Report</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <!-- navbar -->
    
    <div class="admin_nav">
    <a href="admin_dashboard.php"> <div class="admin_navlink"> Dashboard </div></a>
    <a href="admin_course.php"> <div class="admin_navlink"> Course </div></a>
    <a href="admin_lessons.php"><div class="admin_navlink"> Lessons </div></a>
    <a href="admin_student.php"><div class="admin_navlink"> Students </div></a>
    <a href="admin_sellreport.php"><div class="admin_navlink active"> Sell Report </div></a>
    <a href="admin_payment.php"><div class="admin_navlink"> Payment Status </div></a>
    <a href="admin_feedback.php"><div class="admin_navlink"> Feedback </div></a>
    <a href="help_center.php"><div class="admin_navlink"> Help Center </div></a>
    <a href="admin_contact.php"><div class="admin_navlink"> <i class="fas fa-envelope"></i></div></a>
    <a href="admin_profile.php"><div class="admin_navlink"><i class="fas fa-user-circle"></i></div></a>
    <a href="admindata/logout.php"><div class="admin_navlink"> <i class="fas fa-sign-out-alt"></i> </div></a>
    </div>




    <div class="sell_main mtop">
        <form method="POST" class="sell_in" action="">
            <div class="sell_date">
                <div class="s_date">
                    <label for="startdate">Start Date</label>
                    <input class="date_sell" type="date" id="startdate" name="startdate">
                </div>
                <div class="to_date">TO</div>
                <div class="s_date">
                    <label for="enddate">End Date</label>
                    <input class="date_sell" type="date" id="enddate" name="enddate">
                </div>
            </div>
            <input class="sell_btn" name="report" type="submit" value="Generate Report">
        </form>
    </div>


        <?php

          if(isset($_REQUEST['report'])){
            $startdate = $_REQUEST['startdate'];
            $enddate = $_REQUEST['enddate'];

            $sql = "SELECT *FROM courseorder WHERE order_date BETWEEN '$startdate' AND '$enddate'";
            $result = $conn->query($sql);
            if($result->num_rows > 0){
              echo'
              <div class="dash_course_order">
              <div>Sell Details</div>
              </div>
              <div id="container">

<!-- table -->

    <table class="table" >
        <thead class="dash_table">
          <tr>
            <th scope="col">Order ID</th>
            <th scope="col">Course ID</th>
            <th scope="col">Student Email</th>
            <th scope="col">Payment Status</th>
            <th scope="col">Order Date</th>
            <th scope="col">Amount</th>
          </tr>
        </thead>
        <tbody>';
        while($row = $result->fetch_assoc()){
          echo '<tr>
                  <th scope="row">'.$row["order_id"].'</th>
                  <td>'.$row["course_id"].'</td>
                  <td class="email_stu">'.$row["user_email"].'</td>
                  <td>'.$row["status"].'</td>
                  <td>'.$row["order_date"].'</td>
                  <td>'.$row["amount"].'</td>
                </tr>';
              }
              echo '
              </tbody>
            </table>
</div>
      
    <div class="print_sell mdown">
        <button class="sell_btn" onclick="printDiv()">Print</button>
    </div>';

            }
            else{
              echo "<div style='font-size:2rem; font-weight: bold; color: red'> <center>No Message for you</center></div>";
            }
          }
        
        ?>



      

<script>
       function printDiv() {
            var divContents = document.getElementById("container").innerHTML;
            var a = window.open('', '', 'height=500, width=500');
            a.document.write('<html>');
            a.document.write('<body> <h2>Sell Report</h2>');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }
    </script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>