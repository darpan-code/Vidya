<?php 

    if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }

    include('admindata/course_db.php');

    // checking for entry 
    if(isset($_REQUEST['submit_admin'])){

       if(
       ($_REQUEST['admin_id'] == "") ||
       ($_REQUEST['admin_name'] == "") ||
       ($_REQUEST['admin_email'] == "") || 
       ($_REQUEST['admin_password'] == "") || 
       ($_REQUEST['admin_occupation'] == "") ||
       ($_REQUEST['admin_social'] == "")
        ){
            $msg = '<div class="fill_error">Fill All Fields</div>';
            echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
        }
        else {
            $admin_id = $_REQUEST['admin_id'];
            $admin_name = $_REQUEST['admin_name'];
            $admin_email = $_REQUEST['admin_email'];
            $admin_password = $_REQUEST['admin_password'];
            $admin_occupation = $_REQUEST['admin_occupation'];
            $admin_social = $_REQUEST['admin_social'];
            $admin_img = $_FILES['admin_img']['name'];
            $admin_img_temp = $_FILES['admin_img']['tmp_name'];
            $img_folder = '../img/admin_image/'.$admin_img;
            move_uploaded_file($admin_img_temp, $img_folder);


             $sql = "INSERT INTO `admin` ( `id`, `name`, `email`, `password`, `image`, `occupation`, `social`) VALUES ('$admin_id', '$admin_name', '$admin_email', '$admin_password', '$img_folder', '$admin_occupation', '$admin_social')";


             if($conn->query($sql) == TRUE){
                $msg = '<div class="add_success">Admin Added Succesfully</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Admin_Added_Succesfully" />';
            }
            else{
                $msg = '<div class="fill_error">Unable to Add Admin</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Unable_to_Add_Admin" />';
            }
        }
    }
?>


<!DOCTYPE html>
<html>
<head>
	<title>Add New Admin</title>
	<link rel="stylesheet" type="text/css" href="admin_css/add_admin.css">
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <div class="add_admin_main">
        <div class="add_admin_head">Add New Admin</div>
        <div class="add_admin_upper">
            <form class="add_admin_login" action="" method="POST" enctype="multipart/form-data">

            <input class="add_admin_textbox form-control" type="text" id="admin_id" name="admin_id" placeholder="Type your admin id here..." value="" required>
            
            <input class="add_admin_textbox form-control" type="text" id="admin_name" name="admin_name" placeholder="Type your admin name here..." value="" required>

            <input class="add_admin_textbox form-control" type="email" id="admin_email" name="admin_email" placeholder="Type your admin email here..." value="" required>

            <input class="add_admin_textbox form-control" type="password" id="admin_password" name="admin_password" placeholder="Type your admin password here..." value="" required>

            <input class="add_admin_textbox form-control" type="text" id="admin_occupation" name="admin_occupation" placeholder="Type your admin occupation here..." value="" required>
            
            <input class="add_admin_textbox form-control" type="text" id="admin_social" name="admin_social" placeholder="Type your admin social link here..." value="" required>

            <input type="file" class="add_admin_textbox form-control" id="admin_img" name="admin_img" accept="image/png, image/jpeg" required>

                            
                <input class="add_admin_submit" type="submit" value="Add Admin" name="submit_admin">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>


</body>
</html>


