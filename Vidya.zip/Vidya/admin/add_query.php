<?php 

    if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }

    include('admindata/course_db.php');

    // checking for entry 
    if(isset($_REQUEST['submit_query'])){

       if(
       ($_REQUEST['bot_question'] == "") ||
       ($_REQUEST['bot_answer'] == "")
        ){
            $msg = '<div class="fill_error">Fill All Fields</div>';
            echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
        }
        else {
            $bot_question = $_REQUEST['bot_question'];
            $bot_answer = $_REQUEST['bot_answer'];

             $sql = "INSERT INTO chatbot_hints (question, reply) VALUES ('$bot_question', '$bot_answer')";


             if($conn->query($sql) == TRUE){
                $msg = '<div class="add_success">Query Added Succesfully</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Query_Added_Succesfully" />';
            }
            else{
                $msg = '<div class="fill_error">Unable to Add Query</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Unable_to_Add_Query" />';
            }
        }
    }
?>


<!DOCTYPE html>
<html>
<head>
	<title>Add New Query</title>
	<link rel="stylesheet" type="text/css" href="admin_css/add_query.css">
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <div class="add_query_main">
        <div class="add_query_head">Add New Query</div>
        <div class="add_query_upper">
            <form class="add_query_login" action="" method="POST" enctype="multipart/form-data">

            <textarea class="add_query_textbox form-control" id="bot_question" name="bot_question" placeholder="Type your question here..." value="" required></textarea>

            <textarea class="add_query_textbox form-control" id="bot_answer" name="bot_answer" placeholder="Type your answer here..." value="" required></textarea>
          
            <input class="add_query_submit" type="submit" value="Add Query" name="submit_query">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>


</body>
</html>


